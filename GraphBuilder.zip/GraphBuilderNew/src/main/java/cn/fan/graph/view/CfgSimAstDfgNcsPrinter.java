package cn.fan.graph.view;

import cn.fan.graph.model.AstNode;
import cn.fan.graph.model.EdgeTypes;
import cn.fan.graph.model.GraphEdge;
import cn.fan.graph.model.GraphNode;
import cn.fan.graph.utils.DotPrintFilter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.*;


public class CfgSimAstDfgNcsPrinter {

    private String path;
    private StringBuilder str;
    private int index = 0;
    private List<String> leafNodes;
    private Set<GraphEdge> allDFGEdgesList;


    public CfgSimAstDfgNcsPrinter(String path,Set<GraphEdge> allDFGEdgesList) {
        this.path = path;
        str = new StringBuilder("digraph {");
        leafNodes = new ArrayList<>();
        this.allDFGEdgesList = allDFGEdgesList;
    }


    private void BFS(GraphNode root,boolean cfgFlag,boolean astFlag,boolean dfgFlag,boolean ncsFlag) {
        Queue<GraphNode> dealingNodes = new LinkedList<>();
        dealingNodes.add(root);
        while (!dealingNodes.isEmpty()) {
            GraphNode par = dealingNodes.poll();
            String parIndexNum = "";
            if (par.getDotNum() != null) {
                parIndexNum = par.getDotNum();
            } else {
                parIndexNum = "n" + (index++);
                par.setDotNum(parIndexNum);
                str.append(System.lineSeparator() + par.getDotNum() + " [label=\"" + DotPrintFilter.filterQuotation(par.getSimplifyCodeStr()) + "\" , line=" + par.getCodeLineNum()+", hasException=\" "+par.getIsExceptionLabel()+ "\"];");
                if(astFlag) {
                    ASTRecurive(par.getAstRootNode(), par.getDotNum());
                }
            }
            List<GraphNode> adjacentPoints = par.getAdjacentPoints();
            for (GraphNode child : adjacentPoints) {
                if (child.getDotNum() == null) {
                    dealingNodes.add(child);
                    child.setDotNum("n" + (index));
                    index++;
                    str.append(System.lineSeparator() + child.getDotNum() + " [label=\"" + DotPrintFilter.filterQuotation(child.getSimplifyCodeStr()) + "\" , line=" + child.getCodeLineNum() +", hasException=\" "+child.getIsExceptionLabel()+ "\"];");
                    if(astFlag) {
                        ASTRecurive(child.getAstRootNode(), child.getDotNum());
                    }
                }
            }
            if(cfgFlag) {
                for (GraphEdge edge : par.getEdgs()) {
                    str.append(System.lineSeparator() + edge.getOriginalNode().getDotNum() + " -> " + edge.getAimNode().getDotNum() + "[color=" + edge.getType().getColor() + "];");
                }
            }
        }

        if(dfgFlag) {
            for (GraphEdge edge : this.allDFGEdgesList) {
                str.append(System.lineSeparator() + edge.getOriginalNode().getDotNum() + " -> " + edge.getAimNode().getDotNum() + "[color=" + edge.getType().getColor() + "];");
            }
        }

        if(ncsFlag && astFlag) {
            NCS(leafNodes);
        }

        str.append(System.lineSeparator() + "}");
    }


    private void ASTRecurive(AstNode node, String parentNodeName) {
        if (node != null) {
            List<String> attributes = node.getAttributes();
            List<AstNode> subNodes = node.getSubNodes();
            List<String> subLists = node.getSubLists();
            List<List<AstNode>> subListNodes = node.getSubListNodes();

            String ndName = nextNodeName();

            if (!node.toString().equals("")) {
                str.append(System.lineSeparator() + ndName + " [label=\"" + DotPrintFilter.AstNodeFilter(node.getTypeName()) + "\", ast_node=\"true\"];");

            }
            if (parentNodeName != null) {
                str.append(System.lineSeparator() + parentNodeName + " -> " + ndName +"[color="+ EdgeTypes.AST.getColor()+"];");
            }

            for (String a : attributes) {
                String attrName = nextNodeName();
                str.append(System.lineSeparator() + attrName + " [label=\"" + DotPrintFilter.AstNodeFilter(a) + "\", ast_node=\"true\"];");
                str.append(System.lineSeparator() + ndName + " -> " + attrName +"[color="+ EdgeTypes.AST.getColor()+"];");
                if(DotPrintFilter.AstNodeFilter(a).contains("identifier") || DotPrintFilter.AstNodeFilter(a).contains("value") ){
                    leafNodes.add(attrName);
                }
            }

            for (int i = 0; i < subNodes.size(); i++) {
                ASTRecurive(subNodes.get(i), ndName);
            }

            for (int i = 0; i < subLists.size(); i++) {
                String ndLstName = nextNodeName();
                str.append(System.lineSeparator() + ndLstName + " [label=\"" + DotPrintFilter.AstNodeFilter(subLists.get(i)) + "\", ast_node=\"true\"];");
                str.append(System.lineSeparator() + ndName + " -> " + ndLstName +"[color="+ EdgeTypes.AST.getColor()+"];");

                for (int j = 0; j < subListNodes.get(i).size(); j++) {
                    ASTRecurive(subListNodes.get(i).get(j), ndLstName);
                }
            }
        }
    }

    private String nextNodeName() {
        return "n" + (index++);
    }


    public void NCS(List<String> allLeafNodes){
        if(allLeafNodes.size()>1) {
            for (int i=1;i<allLeafNodes.size();i++) {
               str.append(System.lineSeparator() + allLeafNodes.get(i-1) + " -> " + allLeafNodes.get(i) +"[color="+ EdgeTypes.NCS.getColor()+"];");
            }
        }
    }

    public void print(GraphNode root, String methodName, String methodParms,boolean cfgFlag,boolean astFlag,boolean dfgFlag,boolean ncsFlag) {
        BFS(root,cfgFlag,astFlag,dfgFlag,ncsFlag);
        if (!new File(path).exists() && new File(path).isDirectory()) {
            new File(path).mkdir();
        }
        StringBuilder sb = new StringBuilder("simplifyCfgNode");
        if(cfgFlag){
            sb.append("_cfg");
        }
        if(astFlag){
            sb.append("_ast");
        }
        if(dfgFlag){
            sb.append("_dfg");
        }
        if(ncsFlag){
            sb.append("_ncs");
        }
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(
                    new File(path + File.separator + methodName + "." + UUID.randomUUID()+"_"+sb.toString()+"_.dot")));
            bufferedWriter.write(str.toString());
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception e) {
            System.out.println("数据写入ast文件发送异常！");
        }
    }
}
