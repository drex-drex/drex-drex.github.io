package cn.fan.graph.fore;

import cn.fan.graph.service.CGCreater;
import cn.fan.graph.visitor.GlobalVarVisitor;
import cn.fan.graph.visitor.MethodVisitor;
import cn.fan.service.PaserSourceCodeToAst;
import cn.fan.tool.ExtractClassName;
import com.github.javaparser.ast.CompilationUnit;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 构建图的入口
 */
public class GraphBuilder {
    public static void main(String[] args) {

        String dotFileRootPath = "/home/ubuntu/disk1/needScanProjects/five";
        File directory = new File(dotFileRootPath);
        HashMap<String,String> projects = new HashMap<>();
//        projects.put("test","/home/ubuntu/disk1/test");
        for(File file : directory.listFiles())
        {
            if(file.isDirectory())
                projects.put(file.getName(),file.getAbsolutePath());
        }
        
        List<Boolean> structureSignals = new ArrayList<>();
        structureSignals.add(false); //false
        structureSignals.add(false); //false
        structureSignals.add(false); //false
        structureSignals.add(true); //true
        List<Boolean> signals = new ArrayList<>();
        signals.add(true); 
        signals.add(true); 
        signals.add(true); 
        signals.add(true); 
        
        if(structureSignals.size()!=4 || signals.size()!=4){
            try {
                throw new Exception("图结构或者边的信息设置不对，重新设置哪些信息需要生成！");
            } catch (Exception e) {
               return;
            }
        }else{
            if(!structureSignals.get(2) &&!structureSignals.get(3) && signals.get(2)){
                try {
                    throw new Exception("ast节点都没有 你是无法加入ncs边的信息");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if(!structureSignals.get(0) && !structureSignals.get(1) && !structureSignals.get(2)&& !structureSignals.get(3)){
                try {
                    throw new Exception("图没有任何节点信息，请你重新设置！");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        for(Map.Entry<String,String> data:projects.entrySet()) {
            dotFileRootPath = data.getValue();
            List<String> canIn = new ArrayList<String>();
            List<String> notIn = new ArrayList<String>();
            ExtractClassName extractClassName = new ExtractClassName(canIn, notIn);
            HashMap<String, String> paths = new HashMap<String, String>();
            List<String> jarsPath = new ArrayList<String>();
            File projectFile = new File(dotFileRootPath);
            File aimPathFile = new File(data.getValue() +
                    ""+ File.separator + "AST_CFG_PDGdotInfo");
            aimPathFile.mkdir();
            String hasCompileClassesFilePath = projectFile.getAbsolutePath() + File.separator +"Graph_compiled-2.txt";
            FileWriter fileWriter = null;
            try {
                fileWriter = new FileWriter(hasCompileClassesFilePath, true);
            } catch (IOException e) {
                e.printStackTrace();
            }
            List<String> hasCompileClasses = excludeNoUseClasses(hasCompileClassesFilePath);
            extractClassName.findJavaFile(projectFile, paths, jarsPath);
            CGCreater cgCreater = new CGCreater();
            cgCreater.analysisType(paths);
            for (Map.Entry<String, String> pathToClassName : paths.entrySet()) {
                StringBuilder dotRootPath =  new StringBuilder(aimPathFile.getAbsolutePath());
                String name = pathToClassName.getKey().substring(pathToClassName.getKey().lastIndexOf(".") + 1);
                System.out.println("正在解析文件："+pathToClassName.getValue()+File.separator+name + ".java");
                if(!hasCompileClasses.contains(pathToClassName.getValue()+File.separator+name + ".java")) {
                    PaserSourceCodeToAst paserSourceCodeToAst = new PaserSourceCodeToAst(pathToClassName.getValue(), name + ".java");
                    GlobalVarVisitor globalVarVisitor = new GlobalVarVisitor(cgCreater.getPackageToAllType());
                    globalVarVisitor.analysisFieldType(cu);
                    String packageStr = globalVarVisitor.getPackageStr();
                    dotRootPath.append(File.separator).append(packageStr);
                    File packageDir = new File(dotRootPath.toString());
                    if (!packageDir.exists()) {
                        packageDir.mkdirs(); 
                    }
                    try{
                    MethodVisitor methodVisitor = new MethodVisitor(globalVarVisitor.getCurrentPackageAllTypes(), globalVarVisitor.getAllImports(),
                            globalVarVisitor.getAllFields(), structureSignals, signals, dotRootPath.toString(),name + ".java");
                    methodVisitor.visit(cu, null);}
                    catch (Exception e)
                    {
                        continue;
                    }
                   writeCompiledClass(fileWriter, pathToClassName.getValue() + File.separator + name + ".java");
                }
            }
        }
    }

    public static void writeCompiledClass(FileWriter fileWriter, String className) {
        try {
            fileWriter.write(className + "\r\n");
            fileWriter.flush();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private static List<String> excludeNoUseClasses(String filePath) {
        List<String> classMains = new ArrayList<String>();
        File file = new File(filePath);
        try (BufferedReader reader = new BufferedReader(new FileReader(file));) {
            String temp = "";
            while ((temp = reader.readLine()) != null && !temp.equals("")) {
                classMains.add(temp.trim());
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("文件没有找到" + filePath);
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        return classMains;
    }

}
