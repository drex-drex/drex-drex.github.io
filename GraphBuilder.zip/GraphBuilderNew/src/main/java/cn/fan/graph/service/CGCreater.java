package cn.fan.graph.service;

import cn.fan.service.PaserSourceCodeToAst;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;

import java.util.*;


public class CGCreater {
    private HashMap<String, Set<String>> packageToAllType;

    private Set<String> hasDealJavaFiles = null;

    public CGCreater(){
        this.packageToAllType = new HashMap<>();
        this.hasDealJavaFiles = new HashSet<>();
    }

    public void analysisType(HashMap<String, String> paths){
        for (Map.Entry<String, String> pathToClassName : paths.entrySet()) {
            String name = pathToClassName.getKey().substring(pathToClassName.getKey().lastIndexOf(".") + 1);
            if(!hasDealJavaFiles.contains(pathToClassName.getValue()+"\\"+name + ".java")) {
                CompilationUnit cu=null;
                try {
                    PaserSourceCodeToAst paserSourceCodeToAst = new PaserSourceCodeToAst(pathToClassName.getValue(), name + ".java");
                    cu = paserSourceCodeToAst.getCompilationUnit();
                }
                catch (Exception e)
                {
                     continue;
                }
                Optional<PackageDeclaration> packageInfo = cu.findFirst(PackageDeclaration.class);
                String packageStr = "";
                if(packageInfo.isPresent()){
                    packageStr = packageInfo.get().getName().asString();
                }
                Set<String> allAimTypes = new HashSet<>();
                HashMap<TypeDeclaration,String> typeParents = new HashMap<>();
                Queue<TypeDeclaration> queue = new LinkedList<>();
                NodeList<TypeDeclaration<?>> types =cu.getTypes();
                for(TypeDeclaration typeDeclaration:types){
                    queue.add(typeDeclaration);
                    typeParents.put(typeDeclaration,packageStr);
                }
                while(!queue.isEmpty()) {
                    TypeDeclaration tempType = queue.poll();
                    String currentType = null;
                    if(!typeParents.get(tempType).equals("")){
                       currentType = typeParents.get(tempType)+"."+tempType.getNameAsString();
                    }else{
                       currentType = tempType.getNameAsString();
                    }
                    allAimTypes.add(currentType);
                    List<Node> childNodes = tempType.getChildNodes();
                    for(Node node:childNodes){
                        if(node instanceof TypeDeclaration){
                            TypeDeclaration typeDeclaration = ((TypeDeclaration) node).asTypeDeclaration();
                            queue.add(typeDeclaration);
                            typeParents.put(typeDeclaration,currentType);
                        }
                    }
                }
                if(this.packageToAllType.get(packageStr)==null){
                    this.packageToAllType.put(packageStr,allAimTypes);
                }else{
                    this.packageToAllType.get(packageStr).addAll(allAimTypes);
                }
                this.hasDealJavaFiles.add(pathToClassName.getValue()+"\\"+name + ".java");
            }
        }
    }

    public HashMap<String, Set<String>> getPackageToAllType() {
        return packageToAllType;
    }

    public void setPackageToAllType(HashMap<String, Set<String>> packageToAllType) {
        this.packageToAllType = packageToAllType;
    }

    @Override
    public String toString() {
        return "CGCreater{" +
                "packageToAllType=" + packageToAllType +
                ", hasDealJavaFiles=" + hasDealJavaFiles +
                '}';
    }
}
