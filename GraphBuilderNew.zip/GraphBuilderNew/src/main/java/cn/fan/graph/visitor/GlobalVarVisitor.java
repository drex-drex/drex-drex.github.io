package cn.fan.graph.visitor;

import cn.fan.graph.model.DFVarNode;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.type.*;
import org.apache.commons.lang3.StringUtils;

import java.util.*;


public class GlobalVarVisitor {
    private HashMap<String, Set<String>> packageToAllType;
    private List<String> allImports;
    private String packageStr;
    private Set<DFVarNode> allFields;

    public GlobalVarVisitor(HashMap<String, Set<String>> packageToAllType) {
        this.packageToAllType = packageToAllType;
    }

    public void analysisFieldType(CompilationUnit cu) {

        allImports = new ArrayList<>();
        NodeList<ImportDeclaration> imports = cu.getImports();
        for (ImportDeclaration importDeclaration : imports) {
            allImports.add(importDeclaration.getNameAsString());
        }
        Optional<PackageDeclaration> packageInfo = cu.getPackageDeclaration();
        if (packageInfo.isPresent()) {
            packageStr = packageInfo.get().getName().asString();
        }else{
            packageStr = "";
        }
        allFields = new HashSet<>();
        List<FieldDeclaration> all = cu.findAll(FieldDeclaration.class);
        for (FieldDeclaration fieldDeclaration : all) {
            NodeList<VariableDeclarator> variables = fieldDeclaration.getVariables();
            for (VariableDeclarator variableDeclarator : variables) {
                analysisSingleVar(variableDeclarator, allFields);
            }
        }
    }

    private void analysisSingleVar(VariableDeclarator variableDeclarator, Set<DFVarNode> allFields) {
        String varName = variableDeclarator.getNameAsString();
        Type type = variableDeclarator.getType();
        String typeName = parseTypeToTypeStr(type);
        allFields.add(new DFVarNode(varName, typeName));
    }

    public Set<String> getCurrentPackageAllTypes() {
        return this.packageToAllType.get(packageStr);
    }

    public List<String> getAllImports() {
        return allImports;
    }

    public Set<DFVarNode> getAllFields() {
        return allFields;
    }

    public String getPackageStr() {
        return packageStr;
    }

    private String parseTypeToTypeStr(Type type) {
        if (type.isUnknownType()) {
            UnknownType unknownType = type.asUnknownType();
            return "unknownType";
        } else if (type.isUnionType()) {
            List<String> typeStr = new ArrayList<>();
            UnionType unionType = type.asUnionType();
            NodeList<ReferenceType> elements = unionType.getElements();
            for (Type referenceType : elements) {
                typeStr.add(parseTypeToTypeStr(referenceType));
            }
            return StringUtils.join(typeStr, ";");
        } else if (type.isVarType()) {
            VarType varType = type.asVarType();
            return varType.asString();
        } else if (type.isClassOrInterfaceType()) {
            ClassOrInterfaceType classOrInterfaceType = type.asClassOrInterfaceType();
            return analysisTypeLocation(classOrInterfaceType.getNameAsString());
        } else if (type.isArrayType()) {
            ArrayType arrayType = type.asArrayType();
            String s = parseTypeToTypeStr(arrayType.getComponentType());
            return s + "[]";
        } else if (type.isTypeParameter()) {
            TypeParameter typeParameter = type.asTypeParameter();
            return analysisTypeLocation(typeParameter.getNameAsString());
        } else if (type.isPrimitiveType()) {
            PrimitiveType primitiveType = type.asPrimitiveType();
            return "JavaLang" + primitiveType.getType().asString();
        } else if (type.isWildcardType()) {
            WildcardType wildcardType = type.asWildcardType();
            StringBuilder sb = new StringBuilder();
            if (wildcardType.getExtendedType().isPresent()) {
                sb.append(parseTypeToTypeStr(wildcardType.getExtendedType().get()));
                sb.append(";");
            }
            if (wildcardType.getSuperType().isPresent()) {
                sb.append(parseTypeToTypeStr(wildcardType.getSuperType().get()));
            }
            return sb.toString();
        } else if (type.isVoidType()) {
            VoidType voidType = type.asVoidType();
            return voidType.asString();
        } else if (type.isIntersectionType()) {
            IntersectionType intersectionType = type.asIntersectionType();
            List<String> typeStr = new ArrayList<>();
            for (Type t : intersectionType.getElements()) {
                typeStr.add(parseTypeToTypeStr(t));
            }
            return StringUtils.join(typeStr, ";");
        }
        return "";
    }

    private String analysisTypeLocation(String typeName) {
        for (String str : allImports) {
            if (typeName.equals(str.substring(str.lastIndexOf(".") + 1))) {
                return str;
            }
        }
        Set<String> currentPackageTypes = packageToAllType.get(packageStr);
        if (currentPackageTypes != null) {
            for (String packType : currentPackageTypes) {
                if (typeName.equals(packType.substring(packType.lastIndexOf(".") + 1))) {
                    return packType;
                }
            }
        }
        return "java.lang." + typeName;
    }
}
