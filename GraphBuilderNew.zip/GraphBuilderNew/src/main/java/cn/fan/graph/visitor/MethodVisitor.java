package cn.fan.graph.visitor;

import cn.fan.bug.service.RunExcepetionCreater;
import cn.fan.graph.model.DFVarNode;
import cn.fan.graph.model.GraphNode;
import cn.fan.graph.service.ASTCreater;
import cn.fan.graph.service.CFGCreater;
import cn.fan.graph.service.CFGNodeSimplifyer;
import cn.fan.graph.service.DFGCreater;
import cn.fan.graph.view.CfgAstDfgNcsPrinter;
import cn.fan.graph.view.CfgSimAstDfgNcsExprLabelPrinter;
import cn.fan.graph.view.CfgSimAstDfgNcsPrinter;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import java.util.List;
import java.util.Set;
import java.util.UUID;


public class MethodVisitor extends VoidVisitorAdapter<Void> {


    private Set<String> packageToAllType;
    private List<String> imports;
    private Set<DFVarNode> allFields;
    private String path; //dot文件输出的目录
    private String javaFileName;

    private List<Boolean> structureSignals;
    private List<Boolean> signals;

    public MethodVisitor(Set<String> packageToAllType, List<String> imports, Set<DFVarNode> allFields, List<Boolean> structureSignals, List<Boolean> signals, String path,String javaFileName) {
        this.packageToAllType = packageToAllType;
        this.imports = imports;
        this.allFields = allFields;
        this.path = path;
        this.structureSignals = structureSignals;
        this.signals = signals;
        this.javaFileName = javaFileName;
    }

    @Override
    public void visit(MethodDeclaration n, Void arg) {

        if (n.getType() != null) {
            if (n.getParentNode().isPresent()) {
                if (!(n.getParentNode().get() instanceof TypeDeclaration)) {
                    return; //专门针对于匿名对象 匿名对象的方法不处理
                }
                CFGCreater cfgCreater = new CFGCreater();
                List<GraphNode> graphNodes = cfgCreater.buildMethodCFG(n);
                if (structureSignals.get(2) || structureSignals.get(3)) {
                    ASTCreater astCreater = new ASTCreater(cfgCreater.getAllNodesMap());
                    astCreater.buildMethodAST(n);
                }
                DFGCreater dfgCreater = new DFGCreater(cfgCreater.getAllNodesMap());
                if (signals.get(1)) {
                    dfgCreater.buildMethodDFG(n);
                }
                if (structureSignals.get(1) || structureSignals.get(3)) {
                    CFGNodeSimplifyer nodeSimplifyer = new CFGNodeSimplifyer(cfgCreater.getAllNodesMap(), packageToAllType, imports, allFields);
                    nodeSimplifyer.simplifyCFGNodeStr(n);
                }
                for (GraphNode node : graphNodes) {
                    try {
                        if (structureSignals.get(0)) {
                            CfgAstDfgNcsPrinter cfgAstDfgNcsPrinter = new CfgAstDfgNcsPrinter(path, dfgCreater.getAllDFGEdgesList());
                            cfgAstDfgNcsPrinter.print(node, n.getNameAsString(), n.getParameters().size() + "_" + UUID.randomUUID().toString().substring(0, 6), signals.get(0), false, signals.get(1), signals.get(2));
                        } else if (structureSignals.get(1)) {
                            RunExcepetionCreater.labelExprForGraphNode(n.getNameAsString(), n.getBegin().get().line,this.javaFileName, node);
                            CfgSimAstDfgNcsPrinter cfgSimAstDfgNcsPrinter = new CfgSimAstDfgNcsPrinter(path, dfgCreater.getAllDFGEdgesList());
                            cfgSimAstDfgNcsPrinter.print(node, n.getNameAsString(), n.getParameters().size() + "_" + UUID.randomUUID().toString().substring(0, 6), signals.get(0), false, signals.get(1), signals.get(2));
                        } else if (structureSignals.get(2)) {
                            CfgAstDfgNcsPrinter cfgAstDfgNcsPrinter = new CfgAstDfgNcsPrinter(path, dfgCreater.getAllDFGEdgesList());
                            cfgAstDfgNcsPrinter.print(node, n.getNameAsString(), n.getParameters().size() + "_" + UUID.randomUUID().toString().substring(0, 6), signals.get(0), true, signals.get(1), signals.get(2));
                        } else if (structureSignals.get(3) && !signals.get(3)) {
                            RunExcepetionCreater.labelExprForGraphNode(n.getNameAsString(), n.getBegin().get().line,this.javaFileName, node);
                            CfgSimAstDfgNcsPrinter cfgSimAstDfgNcsPrinter = new CfgSimAstDfgNcsPrinter(path, dfgCreater.getAllDFGEdgesList());
                            cfgSimAstDfgNcsPrinter.print(node, n.getNameAsString(), n.getParameters().size() + "_" + UUID.randomUUID().toString().substring(0, 6), signals.get(0), true, signals.get(1), signals.get(2));
                        } else if (structureSignals.get(3) && signals.get(3)) {
                            RunExcepetionCreater.labelExprForGraphNode(n.getNameAsString(), n.getBegin().get().line,this.javaFileName, node);
                            CfgSimAstDfgNcsExprLabelPrinter cfgSimAstDfgNcsExprLabelPrinter = new CfgSimAstDfgNcsExprLabelPrinter(path, dfgCreater.getAllDFGEdgesList());
                            cfgSimAstDfgNcsExprLabelPrinter.print(node, n.getNameAsString(), n.getParameters().size() + "_" + UUID.randomUUID().toString().substring(0, 6), signals.get(0), true, signals.get(1), signals.get(2));
                        }
                    }catch (Exception e){
                        System.out.println("输出方法文件失败："+n.getNameAsString());
                    }
                }
            }
        }
    }
}
