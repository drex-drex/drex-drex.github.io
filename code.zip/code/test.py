import os,sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import torch
from visdom import Visdom
import numpy as np

import torch.multiprocessing
torch.multiprocessing.set_sharing_strategy('file_system')


last_precision = 0
last_recall = 0
last_f1 = 0

def init_panes():
    vis = Visdom(env="test") #这个是env
    loss_panes = vis.line(X=np.array([0.0]),Y=np.array([0.0]),opts=dict(title="test_loss_panes",xlabel="epoch"))
    precison_panes = vis.line(X=np.array([0.0]), Y=np.array([0.0]),opts=dict(title="test_precison_panes",xlabel="epoch"))
    recall_panes = vis.line(X=np.array([0.0]), Y=np.array([0.0]),opts=dict(title="test_recall_panes",xlabel="epoch"))
    f1_panes = vis.line(X=np.array([0.0]), Y=np.array([0.0]),opts=dict(title="test_f1_panes",xlabel="epoch"))
    return vis,loss_panes,precison_panes,recall_panes,f1_panes


vis, loss_panes, precison_panes, recall_panes, f1_panes = init_panes()
j = 0

def test(epoch, dataloader, net, loss_func,opt):
    test_loss = 0
    true_positive = 0
    false_positive = 0
    false_negative = 0
    net.eval()
    for i, (node_indexs, whole_graph_adj, node_exceptions,file_index) in enumerate(dataloader):
        try:
            if opt.cuda:
                node_indexs = node_indexs.to(opt.device)
                whole_graph_adj = whole_graph_adj.to(opt.device)
                node_exceptions = node_exceptions.to(opt.device)

            output = net(node_indexs, whole_graph_adj)

            test_loss += float(loss_func(node_exceptions[0], output))

            if opt.cuda:
                node_exceptions = node_exceptions[0].cpu().numpy().astype(int)
                output = output.cpu().detach().numpy() >=0.5
                output = output.astype(int)
            else:
                node_exceptions = node_exceptions[0].numpy().astype(int)
                output = output.detach().numpy() >= 0.5
                output = output.astype(int)

            for i,single_node_exceptions in enumerate(output):
                  for j in range(len(single_node_exceptions)):
                       if node_exceptions[i][j] == 1 and single_node_exceptions[j] == 1:
                           true_positive += 1
                       elif node_exceptions[i][j] == 1 and single_node_exceptions[j] == 0:
                           false_negative+=1
                       elif node_exceptions[i][j] == 0 and single_node_exceptions[j] == 1:
                           false_positive+=1
            if opt.cuda:
               torch.cuda.empty_cache()
        except RuntimeError as e:
            j+=1
            print("运行时异常！%s"%(j))

    if true_positive + false_positive > 0:
        precision = true_positive / (true_positive + false_positive)
    else:
        precision = 0

    if true_positive + false_negative > 0:
        recall = true_positive / (true_positive + false_negative)
    else:
        recall = 0

    if precision + recall > 0:
        f1 = 2 * precision * recall / (precision + recall)
    else:
        f1 = 0

    test_loss /= len(dataloader.dataset)

    global last_f1

    if f1 > last_f1:
        save_model(net,opt.path,epoch)
        save_node_vec(net.input_tensors, opt.path, epoch,opt)
        last_f1 = f1
    if opt.cuda:
        print("Test set:After {0:d} epoch, Average loss: {1:.4f}, Precision: ({2:.4f}%), Recall: ({3:.4f}%), F1: ({4:0.4f}%)".format(
            epoch,float(test_loss), precision, recall, f1))
    else:
        print(
            "Test set:After {0:d} epoch, Average loss: {1:.4f}, Precision: ({2:.4f}%), Recall: ({3:.4f}%), F1: ({4:0.4f}%)".format(
                epoch, float(test_loss), precision, recall, f1))

def save_model(model,path,epoch):
    file_path = os.path.join(path, str(epoch))
    if not os.path.exists(file_path):
        os.makedirs(file_path,mode=0o777)
    torch.save(model.state_dict(),os.path.join(file_path,"model.pth"))

def save_node_vec(tensor,path,epoch,opt):
    file_path = os.path.join(path,str(epoch))
    if not os.path.exists(file_path):
        os.makedirs(file_path,mode=0o777)
    if opt.cuda:
        np.savetxt(os.path.join(file_path, "input_vectos.csv"), tensor.cpu().detach().numpy(), delimiter=',')
    else:
        np.savetxt(os.path.join(file_path, "input_vectos.csv"), tensor.numpy(), delimiter=',')

