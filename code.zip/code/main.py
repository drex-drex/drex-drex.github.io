import os,sys
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import argparse
import random
import torch
from  data_processing.CFGGraphDataSet import CFGGraphDataSet
from torch.utils.data.dataloader import DataLoader
from models.CFGModel import CFGModel
from loss.LossFunction import LossFunction
from train import train
from test import test
import torch.optim as optim
import numpy as np
from data_processing.ConfigInfo import config_info

import torch.multiprocessing
torch.multiprocessing.set_sharing_strategy('file_system')


parser = argparse.ArgumentParser()
parser.add_argument("--workers",type=int, help='number of data loading workers', default=2)
parser.add_argument("--batchSize",type=int,help="input batch size",default=1)
parser.add_argument("--fileRootPath",type=str,help="the root path of graph file",default="/media")
parser.add_argument('--manualSeed', type=int, help='manual seed')
parser.add_argument('--cuda', default=True, help='enables cuda')
parser.add_argument('--niter', type=int, default=10, help='number of epochs to train for')
parser.add_argument('--n_steps', type=int, default=3, help='propogation steps number of Net')
parser.add_argument('--state_dim', type=int, default=120, help='GGNN hidden state size')
parser.add_argument('--path', type=str,default="/home/path", help='save model path')
parser.add_argument('--verbal', default=True, help='print training info or not')
parser.add_argument('--lr', type=float, default=0.001, help='learning rate')


opt = parser.parse_args()
if opt.manualSeed is None:
    opt.manualSeed = random.randint(1, 10000)
random.seed(opt.manualSeed)
torch.manual_seed(opt.manualSeed)

if opt.batchSize>1:
    raise RuntimeError("当前代码不支持批量训练！")

if opt.cuda:
    torch.cuda.manual_seed_all(opt.manualSeed)

def main(opt):
    train_dataset = CFGGraphDataSet(opt.fileRootPath,config_info.train_set_file,True)
    train_loader = DataLoader(train_dataset,batch_size=opt.batchSize,shuffle=True,num_workers=opt.workers)
    all_node_num = train_dataset.all_node_index_num
    all_exception_num = train_dataset.all_exception_index_num
    test_dataset = CFGGraphDataSet(opt.fileRootPath,config_info.val_set_file, False)
    test_loader = DataLoader(test_dataset, batch_size=opt.batchSize, shuffle=True, num_workers=opt.workers)

    opt.device = torch.device("cuda:0")

    cfg_model = CFGModel(all_node_num,all_exception_num,train_dataset.input_tensors,opt)
    loss = LossFunction()

    if opt.cuda:
       cfg_model.to(opt.device)
       loss.to(opt.device)

    optimizer = optim.Adam(cfg_model.parameters(), lr=opt.lr)

    for epoch in range(0, opt.niter):
       train(epoch,train_loader,cfg_model,loss,optimizer,opt,train_dataset.data)
       test(epoch,test_loader,cfg_model,loss,opt)


if __name__ == '__main__':
    main(opt)