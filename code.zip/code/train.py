import os,sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import torch
from visdom import Visdom
import numpy as np

import torch.multiprocessing
torch.multiprocessing.set_sharing_strategy('file_system')

def init_panes():
    vis = Visdom(env="dev")
    panes = vis.line(X=np.array([0.0]),Y=np.array([0.0]),opts=dict(title="cfg_loss",xlabel="训练次数"))
    return vis,panes

vis, panes = init_panes()


def train(epoch, dataloader, net, loss_func, optimizer, opt,data):
    print("开始训练！")
    net.train()
    j = 0
    temp_loss = 0.

    for i, (node_indexs, whole_graph_adj, node_exceptions,file_index) in enumerate(dataloader):
        try:
            net.zero_grad()
            if opt.cuda:
                node_indexs = node_indexs.to(opt.device)
                whole_graph_adj =  whole_graph_adj.to(opt.device)
                node_exceptions = node_exceptions.to(opt.device)

            output = net(node_indexs, whole_graph_adj)
            loss = loss_func(node_exceptions[0],output)
            loss.backward()
            optimizer.step()
            if opt.cuda:
               temp_loss+=float(loss.data)
            else:
                temp_loss += float(loss.data)
            if i % 100 == 0 and i!=0 and opt.verbal:
                print("after %d epoch ,the Loss : %.4f" % (epoch, temp_loss/100))
                if opt.cuda:
                    vis.line(X=np.array([i]),Y=np.array([temp_loss/100]),win=panes,update="append")
                else:
                    vis.line(X=np.array([i]), Y=np.array([temp_loss/100]), win=panes, update="append")
                temp_loss = 0.
            if opt.cuda:
               torch.cuda.empty_cache()
        except RuntimeError as e:
            j+=1
            print("运行时异常！%s"%(j))


