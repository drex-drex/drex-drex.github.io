import torch
import numpy as np
import pandas as pd


if __name__ == '__main__':
     np.array(pd.read_csv('/home/ubuntu/disk1/similar_dataset1-1/embeddings120.tsv', sep="\t", header=None,engine='python')).astype(np.float32)