#coding=utf-8
import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint
import os,sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class Model(nn.Module):

    def __init__(self,all_exception_num,input_tensor,opt):
       super().__init__()
       self.input_tensors = torch.tensor(input_tensor)
       if opt.cuda:
           self.input_tensors = self.input_tensors.to(opt.device)
       self.output_fc = nn.Sequential(
           nn.Linear(opt.state_dim, all_exception_num),
           nn.Sigmoid()
       )
       self.state_dim = opt.state_dim
       self.n_steps = opt.n_steps
       self.propogator = Propogator(self.state_dim,opt)

    def forward(self, node_indexs, whole_graph_adj):
           current_graph_node_vectors = torch.index_select(self.input_tensors, dim=0,
                                                           index=node_indexs[0])
           for i_step in range(self.n_steps):
               current_graph_node_vectors = checkpoint(self.check_propogator, current_graph_node_vectors,
                                                       whole_graph_adj)
           return self.output_fc(current_graph_node_vectors)

    def check_propogator(self, current_graph_node_vectors, whole_graph_adj):
           return self.propogator(current_graph_node_vectors, whole_graph_adj[0])

class Propogator(nn.Module):
    def __init__(self, state_dim,opt):
        super(Propogator, self).__init__()
        self.state_dim = state_dim
        self.opt = opt
        self.in_fc = nn.Linear(state_dim, state_dim)
        self.in_fc_bias = nn.Parameter(torch.randn(state_dim))
        self.update_gate = nn.Sequential(
            nn.Linear(2 * state_dim, state_dim),
            nn.Sigmoid()
        )
        self.reset_gate = nn.Sequential(
            nn.Linear(2 * state_dim, state_dim),
            nn.Sigmoid()
        )
        self.tansform = nn.Sequential(
            nn.Linear(3 * state_dim, state_dim),
            nn.Tanh()
        )
        self.attention_weight_above = nn.Linear(2*state_dim,1)
        self.cfg_attention = nn.Linear(2 * state_dim, 1)

    def forward(self, node_vectors, adj_matrix):
        H = []
        A = []
        all_attention = 0
        n = adj_matrix.shape[0]
        lru = nn.LeakyReLU(inplace=True)
        sm = nn.Softmax()
        for i in range(3):
            a = torch.matmul(adj_matrix[:,i*n:(n*i)+n], self.in_fc(node_vectors)) + self.in_fc_bias
            a = torch.cat((a, node_vectors), 1)
            z = self.update_gate(a)
            r = self.reset_gate(a)
            h_hat = self.tansform(torch.cat((a, r * node_vectors), 1))
            h = (1 - z) * node_vectors + z * h_hat
            H.append(h)
            h1 = h.unsqueeze(0).repeat(n,1,1)
            h2 = h.unsqueeze(1).repeat(1,n,1)
            ad = sm(lru(self.attention_weight_above(torch.cat([h1, h2], dim=2)).squeeze(2) * adj_matrix[:, i * n:(n * i) + n]))
            A.append(ad)
            all_attention += torch.sum(ad)
        h = torch.empty([n,self.state_dim])
        if self.opt.cuda:
            h = h.to(self.opt.device)
        for i in range(3):
            A[i] = A[i]/all_attention
            h.add_(torch.sum(H[i].unsqueeze(0).repeat(n,1,1)*A[i].unsqueeze(2).repeat(1,1,self.state_dim),dim=1).squeeze(1))
        h = sm(h)
        return h

