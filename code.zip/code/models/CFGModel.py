#coding=utf-8
import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint
import os,sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class CFGModel(nn.Module):

    def __init__(self,all_node_index_num,all_exception_num,input_tensor,opt):
       super().__init__()
       self.input_tensors = nn.Parameter(torch.tensor(input_tensor))
       self.output_fc = nn.Sequential(
           nn.Linear(opt.state_dim, all_exception_num),
           nn.Sigmoid()
       )
       self.state_dim = opt.state_dim
       self.n_steps = opt.n_steps
       self.propogator = Propogator(self.state_dim)


    def forward(self,node_indexs, whole_graph_adj, node_exceptions ):
        current_graph_node_vectors = torch.index_select(self.input_tensors,dim=0,index=node_indexs[0]) #[N,opt.state_dim]
        for i_step in range(self.n_steps):
            current_graph_node_vectors = checkpoint(self.check_propogator,current_graph_node_vectors,whole_graph_adj)
        return self.output_fc(current_graph_node_vectors)

    def check_propogator(self,current_graph_node_vectors,whole_graph_adj):
        return self.propogator(current_graph_node_vectors, whole_graph_adj[0])

class Propogator(nn.Module):
      def __init__(self,state_dim):
          super(Propogator, self).__init__()
          self.state_dim = state_dim
          #公式中第一个参数w
          self.in_fc = nn.Linear(state_dim,state_dim)
          self.in_fc_bias = nn.Parameter(torch.randn(state_dim))
          self.update_gate = nn.Sequential(
              nn.Linear(2*state_dim,state_dim),
              nn.Sigmoid()
          )
          self.reset_gate =  nn.Sequential(
              nn.Linear(2*state_dim,state_dim),
              nn.Sigmoid()
          )
          self.tansform = nn.Sequential(
              nn.Linear(3*state_dim, state_dim),
              nn.Tanh()
          )
          self.cfg_attention = nn.Linear(2*state_dim,1)

      def forward(self, node_vectors,adj_matrix):
          a = torch.matmul(adj_matrix,self.in_fc(node_vectors))+self.in_fc_bias
          a = torch.cat((a,node_vectors),1)
          z = self.update_gate(a)
          r = self.reset_gate(a)
          h_hat = self.tansform(torch.cat((a,r*node_vectors),1))
          h = (1-z)*node_vectors + z*h_hat
          neighbor_matrix = torch.unsqueeze(adj_matrix, 2).expand(adj_matrix.shape[0],adj_matrix.shape[1],self.state_dim)*h #[N,N,state_dim]
          lru = nn.LeakyReLU(inplace=True)
          sm = nn.Softmax()
          attention_matrix = sm(lru(self.cfg_attention(torch.cat((torch.unsqueeze(h,0).expand(adj_matrix.shape[0],h.shape[0],h.shape[1]),neighbor_matrix),2)).squeeze(2)*adj_matrix))
          return torch.matmul(attention_matrix,h)

