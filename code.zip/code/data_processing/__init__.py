#coding=utf-8
# from visdom import Visdom
# import numpy as np
# import time
import pickle
import torch

'''
数据预处理模块.
'''

# viz = Visdom(env = "test3")
#
#
# x, y = 0, 0
# win = viz.line(X=np.array([x]), Y=np.array([y]),opts=dict(title="loss",xlabel="次数"))
#
# for i in range(10):
#     viz.line(X=[np.array(i)],Y=np.array([np.sin(i)]),win=win,update="append")
#     time.sleep(0.1)
if __name__ == '__main__':
    device = torch.device('cuda:0')
    # 定义两个tensor
    dummy_tensor_4 = torch.randn(120, 3, 512, 512).float().to(device)  # 120*3*512*512*4/1000/1000 = 377.48M
    dummy_tensor_5 = torch.randn(80, 3, 512, 512).float().to(device)  # 80*3*512*512*4/1000/1000 = 251.64M

    # 然后释放
    dummy_tensor_4 = dummy_tensor_4.cpu()
    dummy_tensor_5 = dummy_tensor_5.cpu()
    # 这里虽然将上面的显存释放了，但是我们通过Nvidia-smi命令看到显存依然在占用
    torch.cuda.empty_cache()
    # 只有执行完上面这句，显存才会在Nvidia-smi中释放
    print("结束")
