#coding=utf-8

#配置一些全局名称信息
class config_info:

      train_set_file="train_set.txt"
      test_set_file = "test_set.txt"
      val_set_file = "val_set.txt"