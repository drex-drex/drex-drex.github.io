#coding=utf-8

import os,sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

dir_map = {'cfg':'0','dfg':'1','ncs':'2','ast':'3','cfg+dfg':'4','cfg+dfg+ast':'5','cfg+dfg+ast+ncs':'6','cfg+ast+ncs':'7','cfg+ast':'8'}
file_name_list = ["node_index.txt","node_str.txt","whole.graph","in.graph","out.graph","node_exception.txt","exception_str.txt"]
file_name_list_bug = ["node_str-1.txt","node_str.txt","whole.graph","in.graph","out.graph","node_exception.txt","exception_str.txt"]

def read_method_set(file):
    node_strs = []
    with open(file, 'r') as file:
        result = file.readline().strip()
        while result != "" :
            node_strs.append(result.strip())
            result = file.readline().strip()
    return node_strs


def get_root_data_path_info(root_path,method_dir_name):
    total_node_index_file_path = os.path.join(root_path,'node_index.txt')
    total_node_str_file_path = os.path.join(root_path,'node_str.txt')
    total_exception_index_file_path = os.path.join(root_path,'exception_index.txt')
    total_exception_str_file_path = os.path.join(root_path,'exception_str.txt')
    total_vector_file_path = os.path.join(root_path,'embeddings120.tsv')
    total_files = (total_node_index_file_path,total_node_str_file_path,total_exception_index_file_path,total_exception_str_file_path,total_vector_file_path)
    all_method_dirs = []
    if method_dir_name=='dataset1over1' or method_dir_name=='selected_projects':
        dataset1over1Dir = os.path.join(root_path,method_dir_name)
        file_names = os.listdir(dataset1over1Dir)
        for file_name in file_names:
            if os.path.isdir(os.path.join(dataset1over1Dir,file_name)):
                all_method_dirs.append(os.path.join(dataset1over1Dir,file_name))
    else:
        file = os.path.join(root_path, method_dir_name)
        all_method_dirs = read_method_set(file)
    return total_files,all_method_dirs


def parser_cfg_file_info(root_path,method_dir_name="dataset1over1"):
    total_files, all_method_dirs = get_root_data_path_info(root_path,method_dir_name)
    all_files = []
    for method_dir in all_method_dirs:
        print("resolving%s"+method_dir)
        if len(os.listdir(method_dir)) < 8:
            continue
        cfg = []
        cfg_files = []
        cfg.append(cfg_files)
        all_files.append(cfg)
        cfg_dir = os.path.join(method_dir,dir_map.get('cfg'))
        if len(os.listdir(cfg_dir)) < 6:
            continue
        for file_name in file_name_list:
            cfg_files.append(os.path.join(cfg_dir,file_name))
    return total_files,all_files


def parser_cfg_dfg_file_info(root_path,method_dir_name="dataset1over1"):
    total_files, all_method_dirs = get_root_data_path_info(root_path,method_dir_name)
    all_files = []
    for method_dir in all_method_dirs:
        print("resolving%s" + method_dir)
        if len(os.listdir(method_dir)) < 8:
            continue
        cfg_dfg = []
        cfg_dfg_files = []
        cfg_dfg.append(cfg_dfg_files)
        cfg_dfg_dir = os.path.join(method_dir,dir_map.get('cfg+dfg'))
        if len(os.listdir(cfg_dfg_dir)) < 6:
            continue
        for file_name in file_name_list:
            cfg_dfg_files.append(os.path.join(cfg_dfg_dir,file_name))
        all_files.append(cfg_dfg)
    return total_files,all_files


def parser_cfg_dfg_ast_file_info(root_path,method_dir_name="dataset1over1"):
    total_files, all_method_dirs = get_root_data_path_info(root_path,method_dir_name)
    all_files = []
    for method_dir in all_method_dirs:
        print("resolving%s" + method_dir)
        if len(os.listdir(method_dir)) < 8:
            continue
        cfg_dfg_ast = []
        cfg_dfg__ast_files = []
        cfg_dfg_ast.append(cfg_dfg__ast_files)
        cfg_dfg_dir = os.path.join(method_dir, dir_map.get('cfg+dfg+ast'))
        if len(os.listdir(cfg_dfg_dir)) < 6:
            continue
        for file_name in file_name_list:
            cfg_dfg__ast_files.append(os.path.join(cfg_dfg_dir, file_name))
        all_files.append(cfg_dfg_ast)
    return total_files, all_files


def parser_cfg_dfg_ast_ncs_file_info(root_path,method_dir_name="dataset1over1"):
    total_files, all_method_dirs = get_root_data_path_info(root_path,method_dir_name)
    all_files = []
    for method_dir in all_method_dirs:
        print("resolving%s" + method_dir)
        if len(os.listdir(method_dir)) < 8:
            continue
        cfg_dfg_ast_ncs = []
        cfg_dfg__ast_ncs_files = []
        cfg_dfg_ast_ncs.append(cfg_dfg__ast_ncs_files)
        cfg_dfg_dir = os.path.join(method_dir, dir_map.get('cfg+dfg+ast+ncs'))
        if len(os.listdir(cfg_dfg_dir)) < 6:
            continue
        for file_name in file_name_list:
            cfg_dfg__ast_ncs_files.append(os.path.join(cfg_dfg_dir, file_name))
        all_files.append(cfg_dfg_ast_ncs)
    return total_files, all_files


def parser_cfg_dfg_ast_ncs_file_5w_info(root_path,method_dir_name="dataset1over1"):
    total_files, all_method_dirs = get_root_data_path_info(root_path,method_dir_name)
    all_files = []
    for method_dir in all_method_dirs:
        print("resolving%s" + method_dir)
        if len(os.listdir(method_dir)) < 8:
            continue
        cfg_dfg_ast_ncs = []
        cfg_dfg__ast_ncs_files = []
        cfg_dfg_ast_ncs.append(cfg_dfg__ast_ncs_files)
        cfg_dfg_dir = os.path.join(method_dir, dir_map.get('cfg+dfg+ast+ncs'))

        if method_dir[-5:]=='false':
            if len(os.listdir(cfg_dfg_dir)) < 6:
                continue
            for file_name in file_name_list:
                cfg_dfg__ast_ncs_files.append(os.path.join(cfg_dfg_dir, file_name))
        else:
            if not os.path.exists(os.path.join(cfg_dfg_dir,"node_str-1.txt")):
                continue
            for file_name in file_name_list_bug:
                cfg_dfg__ast_ncs_files.append(os.path.join(cfg_dfg_dir, file_name))
        all_files.append(cfg_dfg_ast_ncs)
    return total_files, all_files


def parser_cfg_ast_ncs_file_info(root_path,method_dir_name="dataset1over1"):
    total_files, all_method_dirs = get_root_data_path_info(root_path,method_dir_name)
    all_files = []
    for method_dir in all_method_dirs:
        print("resolving%s" + method_dir)
        if len(os.listdir(method_dir)) < 8:
            continue
        cfg_dfg_ast_ncs = []
        cfg_dfg__ast_ncs_files = []
        cfg_dfg_ast_ncs.append(cfg_dfg__ast_ncs_files)
        cfg_dfg_dir = os.path.join(method_dir, dir_map.get('cfg+ast+ncs'))
        if len(os.listdir(cfg_dfg_dir)) < 6:
            continue
        for file_name in file_name_list:
            cfg_dfg__ast_ncs_files.append(os.path.join(cfg_dfg_dir, file_name))
        all_files.append(cfg_dfg_ast_ncs)
    return total_files, all_files


def parser_cfg_ast_file_info(root_path,method_dir_name="dataset1over1"):
    total_files, all_method_dirs = get_root_data_path_info(root_path,method_dir_name)
    all_files = []
    for method_dir in all_method_dirs:
        print("resolving%s" + method_dir)
        if len(os.listdir(method_dir)) < 8:
            continue
        cfg_dfg_ast_ncs = []
        cfg_dfg__ast_ncs_files = []
        cfg_dfg_ast_ncs.append(cfg_dfg__ast_ncs_files)
        cfg_dfg_dir = os.path.join(method_dir, dir_map.get('cfg+ast'))
        if len(os.listdir(cfg_dfg_dir)) < 6:
            continue
        for file_name in file_name_list:
            cfg_dfg__ast_ncs_files.append(os.path.join(cfg_dfg_dir, file_name))
        all_files.append(cfg_dfg_ast_ncs)
    return total_files, all_files