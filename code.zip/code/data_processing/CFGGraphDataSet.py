#coding=utf-8
import os,sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from torch.utils.data import Dataset
from data_info_config import *
from data_reader import *
import random
import numpy as np
import pandas as pd


'''
关于只加载cfg的图的信息 1.邻接矩阵 2.node的index 3.node 对应的异常类型
'''

class CFGGraphDataSet(Dataset):

    all_exception_index_num = 0
    def __init__(self,file_root_path,method_set_name,is_train=True):
        '''
        初始化总的数据
        :param file_root_path: 存放数据的根目录
        :param method_set_name 保存需要处理的txt文件名字
        :param is_train: boolean值决定当前返回时训练数据还是验证数据
        '''
        if is_train:
            total_files, all_cfg_files = parser_cfg_dfg_ast_file_info(file_root_path,method_set_name)
            print("一共解析cfg文件%d"%len(all_cfg_files))
            #获取所有node的个数 一会用于输入的时候获取对应的index
            self.all_node_index_num = len(read_total_node_index(total_files[0]))
            CFGGraphDataSet.all_exception_index_num = len(read_total_exception_index(total_files[2]))
            self.data = all_cfg_files
            #如果是训练的话，训练的初始向量用doc2vec 提供的
            self.input_tensors = np.array(pd.read_csv(total_files[4],sep="\t",header=None)).astype(np.float32)
        else:
            #验证集
            _, all_cfg_files = parser_cfg_dfg_ast_file_info(file_root_path, method_set_name)
            print("一共解析cfg文件%d" % len(all_cfg_files))
            self.data = all_cfg_files

    def __getitem__(self, index):
        single_method_graph_info = read_cfg_dfg_ast_file_info(self.data[index])
        node_indexs, whole_graph_adj, node_exceptions = single_method_graph_info[0]
        #exception 答案需要转换 N*self.all_exception_index_num
        result = np.zeros((len(node_exceptions),CFGGraphDataSet.all_exception_index_num),dtype=np.float32)
        for i,single_node_exception in enumerate(node_exceptions): #一个node 可能多个异常节点
               for index_1 in single_node_exception:
                   try:
                        if index_1 =='':
                           result[i][len(node_exceptions)-1] = 1.0
                        else:
                           result[i][int(index_1)] = 1.0
                   except Exception as e:
                         result[i][len(node_exceptions)-1] = 1.0
        return node_indexs, whole_graph_adj, result,index

    def __len__(self):
        return len(self.data)


#切分数据集 默认训练集：测试集 8:2
def split_dataset(full_list,ratio=0.8,shuffle=False):
    n_total = len(full_list)
    offset = int(n_total*ratio)
    if n_total<0 or offset<1:
        return [],full_list
    if shuffle:
        random.shuffle(full_list)
    return full_list[:offset],full_list[offset:]