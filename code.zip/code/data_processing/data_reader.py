#coding=utf-8
import os,sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import pickle
import numpy as np
import re

def read_total_node_index(total_node_index_file):
    indexs = []
    with open(total_node_index_file,'r') as file:
         result = file.readline().strip()
         if result != "":
           indexs = result.split("@&@")[0:-1]
    return indexs

def read_total_node_str(total_node_str_file):
    node_strs = []
    with open(total_node_str_file,'r') as file:
        result = file.readline().strip()
        if result != "":
            node_strs = result.split("@&@")[0:-1]
    return node_strs

def read_total_exception_index(total_node_exception_file):
    indexs = []
    with open(total_node_exception_file, 'r') as file:
        result = file.readline().strip()
        while result != "":
            indexs.append(result.strip())
            result = file.readline().strip()
    return indexs

def read_total_exception_str(total_exception_str_file):
    node_strs = []
    with open(total_exception_str_file, 'r') as file:
        result = file.readline().strip()
        while result != "":
            node_strs.append(result.strip())
            result = file.readline().strip()
    return node_strs


def read_cfg_file_info(cfg_files):
    files = cfg_files[0]

    node_indexs = []
    with open(files[0],'r') as node_index_file:
        result = node_index_file.readline().strip()
        if result != "":
            node_indexs = np.array(result.split("@&@")).astype(np.int)

    whole_graph_adj = np.array(pickle.load(open(files[2],"rb"))).astype(np.float32)
    node_exceptions = []
    with open(files[5],'r') as node_exception_file:
        exce = node_exception_file.readline().strip().split("@&@")
        for ex in exce:
            if ex.strip() == "":
                node_exceptions.append(['9'])
            else:
                node_exceptions.append(ex.split(","))
    return [[node_indexs,whole_graph_adj,node_exceptions]]


def read_cfg_dfg_file_info(cfg_dfg_files):
    files = cfg_dfg_files[0]
    node_indexs = []
    with open(files[0], 'r') as node_index_file:
        result = node_index_file.readline().strip()
        if result != "":
            node_indexs = np.array(result.split("@&@")).astype(np.int)

    whole_graph_adj = np.array(pickle.load(open(files[2], "rb"))).astype(np.float32)
    node_exceptions = []
    with open(files[5], 'r') as node_exception_file:
        exce = node_exception_file.readline().strip().split("@&@")
        for ex in exce:
            if ex.strip() == "":
                node_exceptions.append(['9'])
            else:
                node_exceptions.append(ex.split(","))

    return [[node_indexs, whole_graph_adj, node_exceptions]]


def read_cfg_dfg_ast_file_info(cfg_dfg_ast_files):

    files = cfg_dfg_ast_files[0]
    node_indexs = []
    with open(files[0], 'r') as node_index_file:
        result = node_index_file.readline().strip()
        if result != "":
            node_indexs = np.array(re.split("@[&!]@",result)).astype(np.int)

    whole_graph_adj = np.array(pickle.load(open(files[2], "rb"))).astype(np.float32)
    node_exceptions = []
    with open(files[5], 'r') as node_exception_file:
        exce = re.split("@[&!]@", node_exception_file.readline().strip())
        for ex in exce:
            if ex.strip() == "":
                node_exceptions.append(['9'])
            else:
                node_exceptions.append(ex.split(","))

    return [[node_indexs, whole_graph_adj, node_exceptions]]


def read_cfg_dfg_ast_ncs_file_info(cfg_dfg_ast_ncs_files):
    files = cfg_dfg_ast_ncs_files[0]
    node_indexs = []
    with open(files[0], 'r') as node_index_file:
        result = node_index_file.readline().strip()
        if result != "":
            node_indexs = np.array(re.split("@[&!]@",result)).astype(np.int)
    whole_graph_adj = np.array(pickle.load(open(files[2], "rb"))).astype(np.float32)
    node_exceptions = []
    with open(files[5], 'r') as node_exception_file:
        exce = re.split("@[&!]@", node_exception_file.readline().strip())
        for ex in exce:
            if ex.strip() == "":
                node_exceptions.append(['9'])
            else:
                node_exceptions.append(ex.split(","))
    return [[node_indexs, whole_graph_adj, node_exceptions]]


def read_cfg_ast_ncs_file_info(cfg_ast_ncs_files):
    files = cfg_ast_ncs_files[0]
    node_indexs = []
    with open(files[0], 'r') as node_index_file:
        result = node_index_file.readline().strip()
        if result != "":
            node_indexs = np.array(re.split("@[&!]@",result)).astype(np.int)
    whole_graph_adj = np.array(pickle.load(open(files[2], "rb"))).astype(np.float32)
    node_exceptions = []
    with open(files[5], 'r') as node_exception_file:
        exce = re.split("@[&!]@", node_exception_file.readline().strip())
        for ex in exce:
            if ex.strip() == "":
                node_exceptions.append(['9'])
            else:
                node_exceptions.append(ex.split(","))

    return [[node_indexs, whole_graph_adj, node_exceptions]]


def read_cfg_ast_file_info(cfg_ast_files):
    files = cfg_ast_files[0]
    node_indexs = []
    with open(files[0], 'r') as node_index_file:
        result = node_index_file.readline().strip()
        if result != "":
            node_indexs = np.array(re.split("@[&!]@",result)).astype(np.int)
    whole_graph_adj = np.array(pickle.load(open(files[2], "rb"))).astype(np.float32)
    node_exceptions = []
    with open(files[5], 'r') as node_exception_file:
        exce = re.split("@[&!]@", node_exception_file.readline().strip())
        for ex in exce:
            if ex.strip() == "":
                node_exceptions.append(['9'])
            else:
                node_exceptions.append(ex.split(","))

    return [[node_indexs, whole_graph_adj, node_exceptions]]